import React from 'react';
import { Container, Row, Col, Button, Image, Badge } from 'react-bootstrap';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { FaGithub, FaLinkedin } from 'react-icons/fa';
import { techStack } from '../data/resumeData';

import profilePic from 'D:/OLD PC/Desktop/diplomes/CV 2022/pierrick/CV_Alternance/a_project_site/photo2.jpg';

import CV from '../images/CV_images/CV_Alesterd KAMELA.pdf';
function scrollToSection(id) {
  const element = document.getElementById(id);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
}

function Hero() {
  return (
    <section className="hero-section py-5">
      <Container>
        <motion.div
          className="d-flex flex-wrap justify-content-center gap-3 mb-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Button variant="dark" href="https://github.com/JuniorSteve770" target="_blank" className="d-flex align-items-center gap-2">
            My Github
            <FaGithub size={20} />
          </Button>
          <Button onClick={() => scrollToSection('expertise')} variant="outline-primary">
            Professional Xperiences
          </Button>
          <Button onClick={() => scrollToSection('projects')} variant="outline-primary">
            🚀 My Projects
          </Button>
          <Button as={Link} to="/ai-projects" variant="outline-success" className="fw-bold">
            🤖 AI & Algo Trading
          </Button>
          <Button onClick={() => scrollToSection('expertise')} variant="outline-primary">
            My Certifications
          </Button>
          <Button variant="primary" href="https://www.linkedin.com/in/alesterd-kamela-33245b1b3/" target="_blank" className="d-flex align-items-center gap-2">
            <FaLinkedin size={20} /> LinkedIn
          </Button>
        </motion.div>

        <Row className="align-items-center text-start">
          <Col lg={4} className="text-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Image
                src={profilePic}
                roundedCircle
                fluid
                alt="Alesterd Kamela"
                className="mb-4 profile-pic"
                style={{ width: '250px', height: '250px', objectFit: 'cover', border: '5px solid var(--primary-color)' }}
              />
            </motion.div>
          </Col>

          <Col lg={8}>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h6 className="display-6 fw-bold mb-4">
                Quant IT & DevOps | Financial Analyst
              </h6>

              <p className="lead mb-4 text-justify">
                I am a <strong>Quantitative IT Engineer & Financial Data Analyst</strong>. With a dual competence in Software Engineering and Financial Markets, my core value is applying deep IT expertise to solve complex business cases in Front Office, Risk Management, and Data Science.
              </p>
              <p className="lead mb-4 text-justify">
                My professional approach focuses on:
              </p>
              <ul className="lead mb-4 text-justify">
                <li>Automating financial workflows and deploying robust ETL / DevOps pipelines.</li>
                <li>Developing analytical tools for Pricing, Risk Modeling, and Market Analysis.</li>
                <li>Designing scalable architectures for real-time market data processing and algorithms.</li>
                <li>Implementing CI/CD practices to ensure reliable delivery of quantitative solutions.</li>
                <li>Bridging the gap between Trading/Risk constraints and scalable tech infrastructures.</li>
              </ul>
              <p className="lead mb-4 text-justify">
                💡 Core capabilities applied to Finance:
              </p>
              <ul className="lead mb-4 text-justify">
                <li>✅ Quantitative Finance & Market Risk Analysis</li>
                <li>✅ Software Architecture & DevOps Pipelines</li>
                <li>✅ Machine Learning & Data Engineering</li>
              </ul>
            </motion.div>
          </Col>
        </Row>

        <div className="text-center mb-1" style={{ marginTop: '15px' }}>
          <h5 className="fw-bold">🛠 Stack Technique</h5>
          <div className="d-flex flex-wrap justify-content-center gap-2">
            <div className="d-flex flex-wrap justify-content-center gap-1 mt-3">
              {techStack.map((tech, idx) => (
                <Badge bg="dark" key={idx} className="px-3 py-2 fs-6 rounded-pill shadow-sm">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

export default Hero;
