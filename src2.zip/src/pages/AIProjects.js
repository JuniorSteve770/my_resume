import React, { useEffect } from 'react';
import { Container, Row, Col, Card, Badge, Button } from 'react-bootstrap';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const aiProjectsData = [
    {
        title: "1. Machine Learning & Statistical Market Analysis",
        context: "Shifted from supervised static conditions to a Data-Driven unsupervised approach to discover true macroeconomic qualitative states ('Market Regimes').",
        implementation: [
            "Features Engineering: Built normalized Multi-Timeframe (MTF) oscillators (MACD, OsMA, RSI, Stochastic) combining Macro (1D/4H) and Micro (15m/5m) contexts.",
            "Unsupervised Clustering: Deployed K-Means & Gaussian Mixture Models across 100+ assets to auto-classify historical data into natural behavioral regimes (e.g., 'Deep Sleep', 'Bullish Divergence', 'Capitulation')."
        ],
        results: [
            "Established predictive scoring pipelines proving that a static 5m strategy's Win-Rate (e.g., 65%) can surge to 88% when algorithmically aligned with specific ML-discovered Macro Regimes."
        ],
        impact: "Provides actionable insights by implementing machine learning and statistical models directly on complex volatility datasets.",
        skills: ["Python", "Scikit-learn (K-Means)", "Pandas", "TA-Lib", "SQLite", "Volatility Analysis"]
    },
    {
        title: "2. AI-Driven Analytical Tools Development (DQN)",
        context: "Tackled algorithmic institutional structures on Forex (London/NY sessions, NFP news, variable spreads) where standard price-only Deep Learning models fail.",
        implementation: [
            "Complex State Space: Engineered environments feeding the agent MTF candles, dynamic real-time Bid/Ask spreads, and Sine/Cosine encoded session clocks.",
            "RL Framework: Integrated Deep Reinforcement Learning (DQN/PPO) via Ray RLlib & Stable-Baselines3 into a custom gym.Env perfectly simulating MT5 execution mechanics."
        ],
        results: [
            "The RL agent successfully autonomously discovered the 'Ultimate Combo' of statistical filters (RSI, EMA, Volume) while adapting to dynamic spreads to maintain a strict 1:3 Risk:Reward ratio."
        ],
        impact: "Showcases the development of AI-based quantitative tools, translating business needs into robust and practical quantitative solutions.",
        skills: ["Python", "TensorFlow / PyTorch", "Deep Q-Networks (DQN)", "Ray RLlib", "Reinforcement Learning"]
    },
    {
        title: "3. Quantitative Backtesting & Robustness Testing",
        context: "Built the 'Indicator Discovery Lab' (IDL) to eliminate human intuition and mathematically map technical indicator performance across assets and regimes.",
        implementation: [
            "Lab Architecture: Orchestrated a 6-module pipeline converting technical oscillators into virtual trades and performance metrics.",
            "Crash-Testing: Executed Out-Of-Sample Walk-Forward cross-validation logic across double-periods to isolate signal degradation and prevent algorithmic overfitting."
        ],
        results: [
            "Generated an institutional 'Robustness Score' ranking system that heavily penalizes strategies decaying out-of-sample, drastically improving the reliability of live signal deployment."
        ],
        impact: "Demonstrates a solid background in probability, statistics, and time series, essential for the automation and improvement of existing analytical tools.",
        skills: ["Python", "Backtesting", "Walk-Forward Validation", "Statistics", "Probability", "Oscillators"]
    },
    {
        title: "4. Trading Workflow Automation & Live Execution",
        context: "Architected end-to-end data pipelines to bridge the quantitative research lab directly to live front-office execution engines.",
        implementation: [
            "Data Factory: Built automated ETL pipelines downloading, cleaning, and locally storing high-performance OHLCV historic data via REST/WebSockets.",
            "Bridging & Reporting: Auto-generated dozens of Markdown performance reports and compiled a sub-light JSON decision matrix dictating mathematically approved regimes to the strategy executor."
        ],
        results: [
            "Successfully connected the scoring algorithms to MetaTrader 5 (MT5), ensuring live automated positions perfectly adapt to the AI-detected 'Market Weather' in real time."
        ],
        impact: "Proves programming capabilities to automate workflows and comfortably operate in a fast-paced front-office environment with live market connections.",
        skills: ["Python", "MetaTrader 5 (MT5)", "WebSockets", "Data Pipelines", "Automation / ETL", "REST APIs"]
    }
];

function AIProjects() {
    // Scroll to top on mount
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    return (
        <section className="py-5" style={{ backgroundColor: 'var(--dark-bg)', minHeight: '100vh', color: 'var(--text-main)' }}>
            <Container>
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <Button as={Link} to="/" variant="outline-primary" className="mb-4">
                        ← Back to Resume
                    </Button>

                    <h2 className="display-5 fw-bold mb-3 text-white">Quantitative & AI Trading Projects</h2>
                    <p className="lead mb-5 text-muted">
                        A comprehensive overview of my Deep Q-Network (DQN) and algorithmic trading implementations.
                    </p>
                </motion.div>

                <Row className="g-4">
                    {aiProjectsData.map((project, idx) => (
                        <Col xs={12} key={idx}>
                            <motion.div
                                initial={{ opacity: 0, x: -20 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: idx * 0.1 }}
                            >
                                <Card className="shadow-sm h-100 border border-secondary" style={{ backgroundColor: 'var(--card-bg)' }}>
                                    <Card.Body className="p-4">
                                        <Card.Title className="fw-bold fs-4 text-primary mb-3">
                                            {project.title}
                                        </Card.Title>
                                        <div className="mb-4">
                                            <h6 className="fw-bold text-white mb-2 border-bottom border-secondary pb-2">🎯 Context & Objective</h6>
                                            <p className="text-muted text-justify">{project.context}</p>
                                        </div>

                                        <div className="mb-4">
                                            <h6 className="fw-bold text-white mb-2 border-bottom border-secondary pb-2">⚙️ Technical Implementation</h6>
                                            <ul className="text-muted text-justify">
                                                {project.implementation.map((item, i) => (
                                                    <li key={i} className="mb-2">{item}</li>
                                                ))}
                                            </ul>
                                        </div>

                                        <div className="mb-4">
                                            <h6 className="fw-bold text-white mb-2 border-bottom border-secondary pb-2">📊 Outcomes & Results</h6>
                                            <ul className="text-muted text-justify">
                                                {project.results.map((item, i) => (
                                                    <li key={i} className="mb-2">{item}</li>
                                                ))}
                                            </ul>
                                        </div>

                                        <div className="p-3 mb-4 rounded" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', borderLeft: '4px solid var(--primary-color)' }}>
                                            <strong className="text-white">Business Impact / Alignment:</strong> <span className="text-muted">{project.impact}</span>
                                        </div>

                                        <div>
                                            <h6 className="fw-bold text-white mb-2">Technical Core Skills:</h6>
                                            <div className="d-flex flex-wrap gap-2">
                                                {project.skills.map((skill, skillIdx) => (
                                                    <Badge bg="light" text="dark" className="px-3 py-2 border border-secondary" key={skillIdx}>
                                                        {skill}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    </Card.Body>
                                </Card>
                            </motion.div>
                        </Col>
                    ))}
                </Row>
            </Container>
        </section>
    );
}

export default AIProjects;
