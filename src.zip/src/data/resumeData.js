import Hottinguer from '../images/CV_images/Hottinguer.JPG';
import Natixis from '../images/CV_images/NatixisGrd.JPG';
import portotrad from '../images/CV_images/portotrad.JPG';
import Kevmax from '../images/CV_images/kevmax.JPG';

import mlImage from '../images/CV_images/machine learning 181910.png';

export const marketsData = [
  "Equity Capital Market",
  "Debt Capital Market",
  "Derivatives & Structured Products",
  "Forex",
  "Interest Rates",
  "Credit Risk",
  "Cryptocurrencies"
];

export const techStack = [
  // Development & Software Engineering
  "Python (Django, Flask, FastAPI)", "C# / C++", "JavaScript (React, Vue)", "SQL",
  "UML / Merise", "Git / CI/CD", "REST API / GraphQL",

  // Data Science & AI
  "Pandas / NumPy / PyTorch", "Machine Learning", "Econometrics", "PCA / Clustering",

  // Quantitative Finance & Risk
  "Pricing Models", "VaR / CVaR / Stress Testing", "Volatility (SABR, GARCH)", "Portfolio Optimization",

  // Banking Systems & Data Providers
  "Bloomberg", "Summit", "JUMP", "MetaTrader 4/5"
];

export const educationData = [
  {
    degree: "MBA in Trading and Financial Markets",
    institution: "ESLSCA Business School Paris",
    description: "Pricing of Structured Products, Options, Forex, Interest Rates, Credit Ratings (AAA)."
  },
  {
    degree: "Master 2 in Risk Management",
    institution: "University Paris Nanterre",
    description: "Credit Risk (PD, LGD, EAD), Market Risk (VaR, Expected Shortfall), Volatility Models (GARCH, IGARCH, ARIMA)."
  },
  {
    degree: "Master 1 in Data Science & Econometrics",
    institution: "Sorbonne Paris 13",
    description: "Econometrics applied to finance, PCA, Regression Models, Correlation Analysis."
  },
  {
    degree: "Licence in Finance & Econometrics",
    institution: "Rennes",
    description: "Fundamentals of Financial Markets, Asset Classes."
  },
  {
    degree: "Licence in Computer Science (IT)",
    institution: "Rennes",
    description: "Frontend/Backend Development, Security, Object-Oriented Programming, Application Architecture (UML, Merise)."
  }
];

export const experiencesData = [
  {
    company: "BANK HOTTINGUER",
    role: "Risk Management & Quant Developer Apprentice",
    logo: Hottinguer,
    missions: [
      "Developed and maintained full-stack tools for Risk Management models including daily VaR, Stress Testing, and Structured Product Pricing.",
      "Engineered automated ETL pipelines (VBA/Python) to process financial instruments (Bonds, ETFs, UCITS) from Bloomberg into the JUMP software.",
      "Implemented automated batch scripts and SQL databases to calculate and report KPIs and risk metrics, ensuring AMF and SFDR compliance."
    ],
    techStack: ["Python", "VBA", "SQL", "Bloomberg", "JUMP", "Power BI"]
  },
  {
    company: "NATIXIS BANK",
    role: "Financial Analyst & VBA Developer",
    logo: Natixis,
    missions: [
      "Analyzed and processed complex trades (bonds, equity, repo) via Summit Sec with an emphasis on the fixed income life cycle.",
      "Designed and developed a VBA-based ETL system and dynamic pivot tables to automate BI/BA data flows, improving operational performance by 20%.",
      "Managed post-trade operations, valuation controls, settlements, and trade reconciliations."
    ],
    techStack: ["VBA", "Excel", "Summit Sec", "Bloomberg", "Track"]
  },
  {
    company: "PORTOTRAD Academy",
    role: "Quant Developer & Front Office Support",
    logo: portotrad,
    missions: [
      "Developed algorithmic trading tools and custom indicators in Python and MQL for MetaTrader, automating strategy execution.",
      "Built automated data scraping and REST API pipelines to extract economic indicators (NFP, CPI, FED Rates) for fundamental analysis.",
      "Designed, backtested, and optimized trading strategies (scalping, swing) and created automated PnL monitoring dashboards."
    ],
    techStack: ["Python", "C#", "MetaTrader 4/5", "REST APIs", "Web Scraping"]
  },
  {
    company: "KEVMAX SARL",
    role: "Full-Stack Web Developer",
    logo: Kevmax,
    missions: [
      "Developed full-stack web applications and company branding sites using React, PHP, and modern web technologies in an Agile/SCRUM environment.",
      "Authored technical specifications and software architecture documents using UML and Merise methodologies.",
      "Designed and optimized relational databases (SQL, Firebase) and implemented REST/GraphQL APIs."
    ],
    techStack: ["React.js", "Vue.js", "Python", "SQL", "Firebase", "UML/Merise", "Git"]
  }
];

export const projectsData = [
  {
    domain: "Trading & Algorithmic Strategies",
    image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=1470&auto=format&fit=crop", // MetaTrader / Trading charts style
    projects: [
      {
        title: "Algorithmic Trading on Forex Market",
        description: "Development of automated trading strategies with Broker indicators, real-time API data collection, and dynamic position sizing, risk management techniques.",
        techStack: ["Python", "Machine Learning", "Metatrader", "Yahoo Finance API"],
        links: []
      },
      {
        title: "Backtesting Strategies",
        description: "Backtesting frameworks to evaluate trading strategies, including MACD, RSI, and portfolio optimization using Riskfolio-Lib and Python Backtest.",
        techStack: ["Python OOP", "Algo-Trading", "API paradigms", "Binance", "Risk Management"],
        links: ["https://github.com/JuniorSteve770/PYTHON/blob/11d0e9e4987c66bd69e5420c7ff3b05892235f91/BackTesting_Crypto_Projects.ipynb"]
      }
    ]
  },
  {
    domain: "Financial Engineering (Modeling, Pricing, Risk)",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1470&auto=format&fit=crop", // Data dashboard / Analytics style
    projects: [
      {
        title: "VaR; CAViaR; SABR Modeling Tool",
        description: "Implementation of SABR models for volatility smiles (log-normal/normal) and VaR/CAViaR risk modeling to backtest market exposure. Developed the analytical models in Python.",
        techStack: ["Python", "OOP", "Financial Engineering", "Risk Analysis"],
        links: ["https://colab.research.google.com/drive/1eAJnAuMp_T5dm2uIZc445vtATzpmarPL?usp=sharing", "https://github.com/JuniorSteve770/PYTHON/blob/main/RAPORT_PROJET_Mesure%20de%20Risque.pdf"]
      },
      {
        title: "Option Pricing Engine in C++",
        description: "Developed a robust option pricing engine for financial derivatives valuation using C++, implementing Bachelier and Black-Scholes models via Monte Carlo simulations.",
        techStack: ["C++", "Financial Engineering", "Derivatives", "Monte Carlo"],
        links: ["https://github.com/JuniorSteve770/PYTHON/blob/0b53bf945e21eeec14295bfc183eeea59d1b33dc/Implementing-Bachelier-and-Black-Scholes-Models%20in%20C%2B%2B%20Projects.pdf"]
      }
    ]
  },
  {
    domain: "Data Science & Machine Learning",
    image: mlImage,
    projects: [
      {
        title: "Stock Prediction with ML and Ensemble Models",
        description: "Predicting stock trends using Random Forest, Boosting, and ML models.",
        techStack: ["Machine Learning", "Data Science", "Python", "R"],
        links: ["https://github.com/JuniorSteve770/PYTHON/blob/main/Projet%20BIG%20DATA.pdf", "https://github.com/JuniorSteve770/PYTHON/blob/main/PROJET_2PYTHON_KAMELA_Alesterd_M2_BIDABI.pdf.ipynb"]
      },
      {
        title: "Clustering Financial Assets",
        description: "K-Means and PCA for stock clustering and asset analysis.",
        techStack: ["Python", "Clustering", "Finance Analytics"],
        links: ["https://github.com/JuniorSteve770/PYTHON/blob/main/PROJET_2PYTHON_KAMELA_Alesterd_M2_BIDABI.pdf.ipynb"]
      }
    ]
  },
  {
    domain: "Full-Stack Development & Personal Side-Projects",
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=1470&auto=format&fit=crop", // Code editor / Programming style
    projects: [
      {
        title: "Automated Data Scraping Pipeline for Market News",
        description: "Engineered an automated pipeline to extract stock data and macroeconomic indicators (NFP, FOMC) from financial sources using Python APIs and BeautifulSoup.",
        techStack: ["Python", "BeautifulSoup", "API Integration", "JavaScript"],
        links: []
      },
      {
        title: "React Web Applications Portfolio",
        description: "Developed several personal web applications showcasing frontend skills, including a WhatsApp clone, a flow management tool, and company branding sites.",
        techStack: ["React.js", "Vue.js", "JavaScript/HTML/CSS", "Bootstrap", "Google SignIn"],
        links: ["https://juniorsteve770.github.io/react01/", "https://juniorsteve770.github.io/flowplus", "https://juniorsteve770.github.io/whatsapp_build/", "https://youtu.be/-Q5OBsDfG_k"]
      },
      {
        title: "C# / C++ Network & Architecture Study",
        description: "Personal implementation and study of software architecture paradigms (OOP, MVC, SOLID), development processes (TDD, BDD), and networking protocols (TCP/IP).",
        techStack: ["C#", "C++", "Software Architecture", "REST API", "TCP/IP"],
        links: ["https://github.com/JuniorSteve770/PYTHON/blob/main/Projet%20Clients%20en%20C%23%2C%20MySQL%20et%20React.pdf"]
      }
    ]
  }
];
